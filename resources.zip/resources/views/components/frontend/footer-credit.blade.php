<div class="py-6">
    <span class="text-sm text-gray-500 sm:text-center dark:text-gray-400">{!! setting('footer_text') !!}</span>
</div>